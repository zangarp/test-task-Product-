using Market.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Market.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly ILogger<ProductController> _logger;
        private readonly AppDbContext _dbContext;

        public ProductController(ILogger<ProductController> logger, AppDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        [HttpPost]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> CreateNewProduct([FromBody] NewProductRequest request)
        {
            try
            {
                if(string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Description) || request.Price <= 0)
                {
                    return TypedResults.BadRequest("Invalid request data");
                }

                var product = new Product(Guid.NewGuid(), request.Name, request.Description, request.Price, DateTime.Now, DateTime.Now);
                await _dbContext.Products.AddAsync(product);
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("New product created: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create new product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpPut]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> UpdateProductById(Guid productId, [FromBody] NewProductRequest request)
        {
            try
            {
                var product =  await _dbContext.Products.AsNoTracking().FirstOrDefaultAsync(s => s.Id == productId);
                if(product is null)
                {
                    return TypedResults.BadRequest("Product not found");
                }

                if(string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Description) || request.Price <= 0)
                {
                    return TypedResults.BadRequest("Invalid request data");
                }

                product = product with
                {
                    Name = request.Name,
                    Description = request.Description,
                    Price = request.Price,
                    UpdatedAt = DateTime.Now
                };

                _dbContext.Entry(product).State = EntityState.Modified;
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("Product updated: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpDelete]
        public async Task<Results<Ok, BadRequest<string>, StatusCodeHttpResult>> DeleteProductById(Guid productId)
        {
            try
            {
                var product = await _dbContext.Products.FindAsync(productId);
                if(product is null)
                {
                    return TypedResults.BadRequest("Product not found");
                }

                _dbContext.Products.Remove(product);
                await _dbContext.SaveChangesAsync();
                _logger.LogInformation("Product deleted: {ProductId}", product.Id);
                return TypedResults.Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete product");
                return TypedResults.StatusCode(500);
            }
        }

        [HttpGet]
        public async Task<Results<Ok<List<Product>>, StatusCodeHttpResult>> GetAllProductsWithPagination(int page, int pageSize)
        {
            try
            {
                var products = await _dbContext.Products.Skip(page * pageSize).Take(pageSize).ToListAsync();
                return TypedResults.Ok(products);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to get all products");
                return TypedResults.StatusCode(500);
            }
        }
    }

    public sealed record NewProductRequest(string Name, string Description, decimal Price);
}
